package dad.icmit.jpatest;

import dad.icmit.jpatest.domain.Merchandise;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

    public static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("lab13");
    public static EntityManager em = emf.createEntityManager();

    public static void main(String[] args) {

        Merchandise m = new Merchandise();

        m.setId(1l);
        m.setName("Телевизор");
        m.setArticle("109-2121394");

        em.getTransaction().begin();

        // Сохраняем в БД
        em.persist(m);

        em.getTransaction().commit();

        em.close();
        emf.close();
    }
}
