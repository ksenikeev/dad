package dad.icmit.jpatest;

import dad.icmit.jpatest.domain.Merchandise;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

    public static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("lab1");
    public static EntityManager em = emf.createEntityManager();

    public static void main(String[] args) {

        em.getTransaction().begin();

        // Формируем список товаров
        Merchandise m1 = new Merchandise();

        m1.setId(1L);
        m1.setName("Телевизор");
        m1.setArticle("109-2121394");

        Merchandise m2 = new Merchandise();

        m2.setId(2L);
        m2.setName("Холодильник");
        m2.setArticle("119-2325394");

        // Сохраняем в БД товары
        em.persist(m1);
        em.persist(m2);

        em.getTransaction().commit();

        em.close();
        emf.close();
    }
}
