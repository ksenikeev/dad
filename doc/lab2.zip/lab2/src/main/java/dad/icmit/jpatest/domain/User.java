package dad.icmit.jpatest.domain;

import javax.persistence.*;

/**
 * Сущность описывает пользователя, имя таблицы отличается от имени класса, т.к. user - ключевое имя SQL
 */
@Entity
@Table(name = "users")
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "user")
    @SequenceGenerator(name = "user", sequenceName = "user_seq", allocationSize=1)
    private Long id;

    private String Name;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return Name;
    }

    public void setName(String name) {
        Name = name;
    }
}
