package dad.icmit.jpatest;

import dad.icmit.jpatest.domain.Basket;
import dad.icmit.jpatest.domain.Merchandise;
import dad.icmit.jpatest.domain.User;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

public class Main {

    public static final EntityManagerFactory emf = Persistence.createEntityManagerFactory("lab2");
    public static EntityManager em = emf.createEntityManager();

    public static void main(String[] args) {

        em.getTransaction().begin();

        // Формируем список товаров
        Merchandise m1 = new Merchandise();

        //m1.setId(1L);
        m1.setName("Телевизор");
        m1.setArticle("109-2121394");

        Merchandise m2 = new Merchandise();

        //m2.setId(2L);
        m2.setName("Холодильник");
        m2.setArticle("119-2325394");

        // Сохраняем в БД товары
        em.persist(m1);
        em.persist(m2);

        // Создаем покупателя
        User user = new User();
        user.setName("Покупатель");

        // Создаем корзину
        Basket basket = new Basket();
        basket.setUser(user);

        // Создаем перечень товаров, которые мы кладем в корзину
        List<Merchandise> merchandiseList = new ArrayList<Merchandise>();
        merchandiseList.add(m1);
        merchandiseList.add(m2);
        basket.setMerchandiseList(merchandiseList);

        em.persist(basket);

        em.getTransaction().commit();

        // поиск товара по id
        Merchandise merch = em.find(Merchandise.class, 2L);

        System.out.println("Merchandise: "+merch.getId()+" "+merch.getName()+
        		" "+ merch.getArticle());
        
        // Список товаров
        Query query = em.createQuery("select m from Merchandise m where upper(m.name) = upper( :name )").
                setParameter("name", "Телевизор");

        List<Merchandise> resultList = query.getResultList();
        
        for (Merchandise m : resultList) {
        	System.out.println("Merchandise: "+m.getId()+" "+m.getName()+
            		" "+ m.getArticle());
        }

        // Получить корзину по id
        Basket b = em.find(Basket.class, 1l);
        System.out.println("Корзина - id = " + basket.getId()+", покупатель - "+b.getUser().getName());
        
        em.close();
        emf.close();
    }
}
