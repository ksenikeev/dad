package dad.icmit.jpatest.domain;

import javax.persistence.*;
import java.util.List;

/**
 * Сущность описывает корзину
 */
@Entity
public class Basket {

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "basket")
    @SequenceGenerator(name = "basket", sequenceName = "basket_seq", allocationSize=1)
    private Long id;

    /* Пользователь */
    @ManyToOne(cascade = CascadeType.ALL)
    private User user;

    /* Список товаров в корзине */
    @OneToMany(cascade = CascadeType.ALL)
    private List<Merchandise> merchandiseList;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public List<Merchandise> getMerchandiseList() {
        return merchandiseList;
    }

    public void setMerchandiseList(List<Merchandise> merchandiseList) {
        this.merchandiseList = merchandiseList;
    }
}
