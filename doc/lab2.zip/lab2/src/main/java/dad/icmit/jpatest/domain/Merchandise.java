package dad.icmit.jpatest.domain;


import javax.persistence.*;

/**
 * Сущность описывает товар
 */
@Entity
@Table( name = "merchandise")
public class Merchandise {

    // Первичный ключ - автоматическая генерация с помощью последовательности merchandise_seq
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "Merchandise")
    @SequenceGenerator(name = "Merchandise", sequenceName = "merchandise_seq", allocationSize=1)
    private Long id;

    private String name;

    private String article;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getArticle() {
        return article;
    }

    public void setArticle(String article) {
        this.article = article;
    }
}
